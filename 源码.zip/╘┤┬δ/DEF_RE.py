#首先读取输入的DFA
filename = 'DFA.txt'
with open(filename) as f:
    lines = f.readlines()
#     for line in lines:
#         print(line)
str_list=[]
for i in range(len(lines)):
    str_list.append(lines[i].split())
print("读取文件成功,文件内容如下",str_list)

#字母表
char_list=[]
for i in range(len(str_list[0])):
    char_list.append(str_list[0][i])
print('字母表为',char_list)

#初始列表
init_list=[]
for i in range(1,len(str_list)):
    for j in range(len(str_list[i])):
        init_list.append(str_list[i][j])
print('原始列表内容为',init_list)

#列表清洗
state_list=[]
start=''
end=''
for i in range(len(init_list)):
    if "#" in init_list[i]:
        start = init_list[i].strip("#")
        print("初始状态为",start)
        if not start in state_list:
            state_list.append(start)
    elif "*" in init_list[i]:
        end = init_list[i].strip("*")
        print("终止状态为",end)
        if not end in state_list:
            state_list.append(end)
    else:
        if not init_list[i] in state_list:
            state_list.append(init_list[i])

print("总共有",len(state_list),"个状态,","状态集合为",state_list)

str_list.remove(str_list[0])#删除字母表一行
temp=''
for i in range(len(str_list)):
    for j in range(len(str_list[i])):
        if "#" in str_list[i][j]:
            temp=str_list[i][j].strip("#")
            str_list[i][j]=temp
        if "*" in str_list[i][j]:
            temp=str_list[i][j].strip("*")
            str_list[i][j]=temp
print("DFA关系图为",str_list)

#给状态编号
for i in range(len(state_list)):
    print("状态",state_list[i],"编号为",state_list[i][1])
    
#便于字典键取名
def new_name(i,j,k):
    return 'R'+i+j+k

dic={}
for i in range(len(state_list)):
    for j in range(len(state_list)):
        name=new_name(str(i),str(j),'-1')
        dic[name]="NULL"
print(dic)

def initial(x,y,z):
    str1=''
    str2=''
    if y != z:
        str1='R'+x+y+'-1'
        dic[str1]="0"#这个地方其实应该使用字母表来表示更具有鲁棒性
        str2='R'+x+z+'-1'
        dic[str2]="1"
    else:
        str1='R'+x+y+'-1'
        dic[str1]="(0+1)"
        
for i in range(len(str_list)):
    initial(str_list[i][0][1],str_list[i][1][1],str_list[i][2][1])
print("初始化完成，结果如下:\n")
print(dic)

#定义运算
def link(str1,str2):
    if str1 != "NULL" and str2 !='NULL':
        return str1+str2
    else:
        return 'NULL'
def join(str1,str2):
    if str1!='NULL' and str2 !='NULL':
        return "("+str1+'+'+str2+")"
    elif str1 =='NULL' and str2!='NULL':
        return str2
    elif str2 =='NULL' and str1!='NULL':
        return str1
    else:
        return 'NULL'
        
#定义递归函数
def res(start,end,max):
    dic_name=new_name(start,end,max)
    if dic_name in dic:
        return dic[dic_name]
    else:
        return join(link(link(res(start,max,str(int(max)-1)),link(res(max,max,str(int(max)-1)),'*')),res(max,end,str(int(max)-1))),res(start,end,str(int(max)-1)))
        
res(start[1],end[1],str(len(state_list)-1))